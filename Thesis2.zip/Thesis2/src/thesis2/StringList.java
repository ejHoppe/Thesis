package thesis2;

import java.util.ArrayList;

class StringList extends ArrayList<String>
{

}
