package thesis2;

import java.util.ArrayList;


public class WeightList extends ArrayList<Weight>{

}
