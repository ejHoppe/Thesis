package thesis2;

import java.util.ArrayList;


class PatternList extends ArrayList<Pattern>{

}
