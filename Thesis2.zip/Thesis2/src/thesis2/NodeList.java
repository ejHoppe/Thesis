package thesis2;

import java.util.ArrayList;


public class NodeList extends ArrayList<Node>{

}
